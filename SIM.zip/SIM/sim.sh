cp -R Code/. sim
cd sim
g++ economic_tana.cpp functions.cpp species_class.cpp -std=c++11
./a.out
